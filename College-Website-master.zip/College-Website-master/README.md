# College-Website

## Screenshot

![App Screenshot](https://i.ibb.co/ngzvB02/Screenshot-121.png)


## Features

- Students can fill out college admission form
- They can know about the college campus and the facilities offered by the college.
- Students can check their fees using this website



https://jaydipsinh-collegewebsite.netlify.app
## Tech Stack

**Client:** HTML, CSS, JAVASCRIPT



## Feedback

If you have any feedback, please reach out to us at jaydipsinhsolanki9297@gmail.com


## Authors

- [@jaydipsinh13](https://www.github.com/jaydipsinh13)


## 🔗 Links
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/jaydipsinhsolanki/)


